# 📦 Deploy Fullstack com Kubernetes: React + Flask + PostgreSQL

Este projeto demonstra o deploy de uma aplicação fullstack em Kubernetes com frontend em **React**, backend em **Flask** e banco de dados **PostgreSQL**, com foco em organização, boas práticas e alta disponibilidade.

---

## 📁 Estrutura do Projeto

```
projeto-k8s-deploy/
├── backend/              # Flask + Docker + Deployment + Service
├── frontend/             # React + Docker + Deployment + Service
├── database/             # PostgreSQL StatefulSet + PVC + Secret
├── ingress/              # Regras do IngressController
├── namespace.yaml        # Criação do namespace 'app-namespace'
```

---

## 🚀 Componentes e Configurações

### ✅ Frontend (React)

- **Deployment com 2 réplicas**
- **Service tipo ClusterIP**
- **Build com `.env` para variável `VITE_API_URL`**
- Dockerfile multistage com NGINX
- Usa `ConfigMap` para consumir a API URL em tempo de build

### ✅ Backend (Flask)

- **Deployment com 2 réplicas**
- **Service tipo ClusterIP**
- Conectado ao banco via `DB_USER`, `DB_PASSWORD` (Secret)
- Usa `ConfigMap` para `DB_HOST`, `DB_NAME`

### ✅ Banco de Dados (PostgreSQL)

- **StatefulSet com PVC via `volumeClaimTemplates`**
- Volume montado em `/var/lib/postgresql/data`
- Secrets (`POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`)

### ✅ Configuração e Segurança

- `ConfigMap`:
  - API URL no frontend
  - Variáveis do banco no backend
- `Secret`:
  - Banco de dados: `db-secret`
  - Backend: `backend-secret`

### ✅ Ingress

- **IngressController NGINX**
- Regras de rota:
  - `/` → Frontend
  - `/api(/|$)(.*)` → Backend

---

## 🌐 Acesso

Após deploy:

- 🌍 Acesse via: `http://app.local`
- API: `http://app.local/api`
- Frontend: página principal da aplicação

Certifique-se de que o domínio `app.local` resolve corretamente para seu cluster (por exemplo, adicione no `/etc/hosts` se necessário).

---

## 🗂️ Comandos Úteis

### Criar namespace
```bash
kubectl apply -f namespace.yaml
```

### Deploy dos componentes
```bash
kubectl apply -f database/
kubectl apply -f backend/
kubectl apply -f frontend/
kubectl apply -f ingress/
```

### Reiniciar um componente (exemplo: frontend)
```bash
kubectl rollout restart deployment frontend -n app-namespace
```

---

## ✅ Requisitos Atendidos

| Requisito                            | Status |
|-------------------------------------|--------|
| Deploy funcional                    | ✅     |
| ConfigMap e Secret utilizados       | ✅     |
| Ingress configurado corretamente    | ✅     |
| Volume persistente no PostgreSQL    | ✅     |
| Alta disponibilidade (2 réplicas)   | ✅     |
| Organização e boas práticas         | ✅     |

---

## ✨ Possíveis Melhorias (Bônus)

- [ ] Adicionar `readinessProbe` e `livenessProbe` no backend
- [ ] Habilitar TLS com Cert-Manager
- [ ] Monitoramento com Prometheus/Grafana

---

## 👨‍💻 Desenvolvido por

- **Nome:** Jardson Silva
- **Curso:** [Seu curso, ex: Ciência da Computação / Redes de Computadores]
- **Instituição:** IFPB